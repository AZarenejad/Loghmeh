package ir.ac.ut.ece.ie.servlets;

import ir.ac.ut.ece.ie.Models.Delivery;
import ir.ac.ut.ece.ie.Models.DeliveryStatus;
import ir.ac.ut.ece.ie.Models.Order;
import ir.ac.ut.ece.ie.Models.Repository;
import ir.ac.ut.ece.ie.utilities.Utility;
import org.json.simple.JSONArray;

import javax.imageio.IIOException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalTime;

public class GetFoodPartyList implements Runnable {

    @Override
    public void run()  {
        Repository repository = Repository.getInstance();
        JSONArray jsonArray = Utility.requestFoodPartApiGetList();
        repository.getListOfFoodPartyFromUrl(jsonArray);
    }
}


