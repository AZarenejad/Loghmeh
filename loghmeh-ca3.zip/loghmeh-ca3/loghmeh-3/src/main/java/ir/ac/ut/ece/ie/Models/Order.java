package ir.ac.ut.ece.ie.Models;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import static java.time.temporal.ChronoUnit.SECONDS;

public class Order {
    private int id;
    private Map<Menu, Integer> menus;
    private Map<PartyMenu,Integer> party_menus;
    private String restaurantName;
    private String restaurantId;
    DeliveryStatus status;
    int totalDeliveryTime;
    LocalTime timeGiveToDelivery;
    String deliverPersonId;


    public Order() {
        menus = new HashMap<Menu, Integer>();
        party_menus = new HashMap<PartyMenu,Integer>();
        restaurantName = null;
        restaurantId = null;
        status = DeliveryStatus.NOT_FINALIZING;
    }

    public String remainingTime(){
        long dif = timeGiveToDelivery.until(LocalTime.now(),SECONDS);
        if(dif < totalDeliveryTime){
            System.out.println(dif);
            return LocalTime.MIN.plusSeconds(totalDeliveryTime- dif).toString();
        }
        this.setStatus(DeliveryStatus.DONE);
        return "00:00:00";

    }

    public void chooseStatus(){
        long dif = timeGiveToDelivery.until(LocalTime.now(),SECONDS);
        if(dif < totalDeliveryTime){
            return;
        }
        this.setStatus(DeliveryStatus.DONE);
    }

    public void orderGiveToDeliverySetTime(LocalTime now , String deliverPersonId){
        this.timeGiveToDelivery = now;
        this.deliverPersonId = deliverPersonId;
    }


    public void setTotalDeliveryTime(int seconds){
        this.totalDeliveryTime = seconds;
    }


    public void setStatus(DeliveryStatus status) {
        this.status = status;
    }

    public DeliveryStatus getStatus() {
        return status;
    }

    public void addFood(Menu menu) {
        if (menus.containsKey(menu)) {
            menus.replace(menu, menus.get(menu) + 1);
        }
        else {
            menus.put(menu, 1);
        }
    }

    public void addPartyFood(PartyMenu menu){
        if(party_menus.containsKey(menu)){
            party_menus.replace(menu,party_menus.get(menu)+1);
        }
        else{
            party_menus.put(menu,1);
        }
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public void setRestaurantId(String restaurantId){
        this.restaurantId = restaurantId;
    }

    public String getRestaurantId(){
        return this.restaurantId;
    }



    public Map<Menu, Integer> getMenus() {
        return menus;
    }


    public Map<PartyMenu,Integer> getPartyMenus(){
        return party_menus;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id){
        this.id = id;
    }
    public String getRestaurantName() {
        if (restaurantName != null)
            return restaurantName;
        return "";
    }

    public int getFoodCount(Menu menu) {
        return menus.get(menu);
    }

    public int getFoodCount(PartyMenu menu){
        return party_menus.get(menu);
    }

    public void deleteMenuFromOrder(int foodParty , String foodName){
        if(foodParty==0){
            Iterator<Map.Entry<Menu, Integer> >
                    iterator = menus.entrySet().iterator();
            // Iterate over the HashMap
            while (iterator.hasNext()) {
                Map.Entry<Menu, Integer> entry = iterator.next();
                // Check if this key is the required key
                if (foodName.equals(entry.getKey().getName())) {
                    // Remove this entry from HashMap
                    System.out.println("here we remove food from order!");
                    iterator.remove();
                }
            }
            System.out.println("user delete " + foodName + " from his/her order");
        }
        else{
            Iterator<Map.Entry<PartyMenu, Integer> >
                    iterator = party_menus.entrySet().iterator();
            // Iterate over the HashMap
            while (iterator.hasNext()) {
                Map.Entry<PartyMenu, Integer> entry = iterator.next();
                // Check if this key is the required key
                if ( foodName.equals(entry.getKey().getName())) {
                    // Remove this entry from HashMap
                    iterator.remove();
                }
            }
            System.out.println("user delete " + foodName + " from his/her order");
        }
    }





}