package ir.ac.ut.ece.ie.servlets;

import ir.ac.ut.ece.ie.Models.Delivery;
import ir.ac.ut.ece.ie.Models.DeliveryStatus;
import ir.ac.ut.ece.ie.Models.Order;
import ir.ac.ut.ece.ie.Models.Repository;
import ir.ac.ut.ece.ie.utilities.Utility;
import org.json.simple.JSONArray;

import java.time.LocalTime;
import java.util.ArrayList;

public class GetDeliveryList implements Runnable {

    @Override
    public void run() {
        System.out.println("10 sec passed.");
        Repository repository = Repository.getInstance();
        if(repository.getUser().getNotFoundDelivery().size()!=0) {
            System.out.println("there is some order in user that did not match with any delivery!" +
                    "handle here in run part 30 sec...");
            JSONArray jsonArray = Utility.requestDeliveryApiGetList();
            repository.getListOfDeliveryFromUrl(jsonArray);
            if (repository.getDeliveries().size() != 0) {
                ArrayList<Order> orders = (ArrayList<Order>) repository.getUser().getNotFoundDelivery().clone();
                for (Order order : orders) {
                    System.out.println("try to find delivery with min time for order with id " +
                            order.getId() + " that is in notFoundDelivery list!");
                    Delivery findDelivery = repository.findDeliveryForOrder(order);
                    System.out.println("delivery find is:==> " + findDelivery);
                    order.orderGiveToDeliverySetTime(LocalTime.now(), findDelivery.getId());
                    order.setStatus(DeliveryStatus.DELIVERING);
                    repository.getUser().getNotFoundDelivery().remove(order);
                }
            }
        }
    }
}