package ir.ac.ut.ece.ie.Models;

public enum DeliveryStatus {
    FINDING_DELIVERY ("finding delivery"),
    DELIVERING ("delivering"),
    DONE ("done"),
    NOT_FINALIZING ("not finalizing");


    private final String name;

    private DeliveryStatus(String s) {
        name = s;
    }


    public String toString() {
        return this.name;
    }
}
