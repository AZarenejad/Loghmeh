package ir.ac.ut.ece.ie.servlets;

import ir.ac.ut.ece.ie.Models.Repository;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/show_restaurant")
public class showRestaurant extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Repository repository = Repository.getInstance();
        String restaurantId = request.getParameter("restaurant_id");
        System.out.println("here " + restaurantId );
        if (!repository.isRestaurantExist(restaurantId)) {
            response.sendError(404,"Restaurant not exist with id " + restaurantId +"!");
        } else if (!repository.restaurantAvailable(repository.getRestaurantWithId(restaurantId))) {
            response.sendError(403,"Restaurant with id " + restaurantId +" not available for user!");

        } else {
            response.sendRedirect("show_restaurant.jsp?restaurant_id=" + restaurantId);
        }

    }
}
