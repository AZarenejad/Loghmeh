package ir.ac.ut.ece.ie.Models;
import ir.ac.ut.ece.ie.Exceptions.*;
import ir.ac.ut.ece.ie.utilities.Request;
import ir.ac.ut.ece.ie.utilities.Utility;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.*;
import org.apache.commons.lang3.ArrayUtils;
import java.time.LocalTime;



public class Repository {
    private ArrayList<Restaurant> restaurants;
    private User user;
    private static Repository instance;
    private ArrayList<Delivery> deliveries;
    private ArrayList<FoodParty> foodParties;
    private int currUserId = 1;
    private static int PERIOD_GET_FOOD_PARTY = 120;

    private Repository() {
        restaurants = new ArrayList<Restaurant>();
        deliveries = new ArrayList<Delivery>();
        foodParties = new ArrayList<FoodParty>();
    }

    public static Repository getInstance() {
        if (instance == null) {
            instance = new Repository();
            String restaurantUrl = "http://138.197.181.131:8080/restaurants";
            try {
                String jsonRestaurants = Request.get(restaurantUrl);
                JSONParser parser = new JSONParser();
                JSONArray jsonArray = new JSONArray();
                jsonArray = (JSONArray) parser.parse(jsonRestaurants);
                Utility.addRestaurantFromJSONArray(instance, jsonArray);
            } catch (Exception e) {
                e.printStackTrace();
            }
            instance.addUser("Alireza", "Zarenejad", "+989102796696", "alireza.zarenejad99@gmail.com");
        }
        return instance;
    }

    public boolean isUserSelectFoodParty(User user){
        return user.isChosenFoodParty();
    }


    public String estimateTime(String restaurantId){
        Restaurant restaurant = getRestaurantWithId(restaurantId);
        int time_find_delivery = 60;
        int average_velocity = 5;
        double distance_from_user =  restaurant.distanceFromUser();
        int total_time = time_find_delivery + (int)((1.5)*(distance_from_user/average_velocity));
        return LocalTime.MIN.plusSeconds(total_time).toString();
    }

    public ArrayList<Delivery> getDeliveries(){
        return this.deliveries;
    }

    public ArrayList<Restaurant> getRestaurants(){
        return this.restaurants;
    }

    public ArrayList<FoodParty> getFoodParties(){
        return this.foodParties;
    }

    public void getListOfFoodPartyFromUrl(JSONArray jsonArray) {
        for(FoodParty foodParty:foodParties){
            String restaurantId = foodParty.getRestaurantId();
            Restaurant restaurant = getRestaurantWithId(restaurantId);
            ArrayList<PartyMenu> partyMenus = foodParty.getMenus();
            for(PartyMenu menu:partyMenus){
                Menu menu_to_add = new Menu(menu.getName(),menu.getDescription(),menu.getPopularity(),
                        menu.getOldPrice(),menu.getUrlImage());
                restaurant.addMenu(menu_to_add);
            }
        }
        foodParties = new ArrayList<FoodParty>();
        for (int i = 0; i < jsonArray.size(); i++) {
            String restaurantId = ((JSONObject) jsonArray.get(i)).get("id").toString();
            String restaurantName = ((JSONObject) jsonArray.get(i)).get("name").toString();
            Location restaurantLocation = new Location((JSONObject) ((JSONObject) (jsonArray.get(i))).get("location"));
            String restaurantUrl = ((JSONObject) jsonArray.get(i)).get("logo").toString();
            if (!isRestaurantExist(restaurantId)) {
                System.out.println("new restaurant " + restaurantName +" with id " + restaurantId
                        + " added to database from foodParty info getting from url!");
                Restaurant new_restaurant = new Restaurant(restaurantId, restaurantName, restaurantUrl, restaurantLocation);
                this.restaurants.add(new_restaurant);
            }
            if(!this.isRestaurantExistInFoodParty(restaurantId)) {
                FoodParty foodParty = new FoodParty(restaurantId, restaurantName, restaurantUrl, restaurantLocation ,PERIOD_GET_FOOD_PARTY);
                JSONArray array_menus_party = (JSONArray) ((JSONObject) jsonArray.get(i)).get("menu");
                for (int k = 0; k < array_menus_party.size(); k++) {
                    foodParty.addMenu(new PartyMenu((JSONObject) array_menus_party.get(k)));
                }
                foodParties.add(foodParty);
            }
            else{
                System.out.println("repeated id of restaurant in jsonArray get from url." +
                        "you have already add restaurant " + restaurantName + " with id " +
                        restaurantId);
            }
        }
        System.out.println(jsonArray.toJSONString());
    }


    public boolean isRestaurantExistInFoodParty(String restaurantId){
        for(int i=0;i<foodParties.size();i++){
            if(foodParties.get(i).getRestaurantId().equals(restaurantId)){
                return true;
            }
        }
        return  false;
    }

    public void addUser(String name , String family , String phone , String email){
        user = new User(currUserId,name , family , phone , email);
        currUserId+=1;
    }

    public boolean isRestaurantExist(String id){
        for (int i=0;i<restaurants.size();i++){
            if(restaurants.get(i).getId().equals(id)){
                return true;
            }
        }
        return false;
    }

    public boolean deliveryExist(String id) {
        for (Delivery delivery : deliveries) {
            if (delivery.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }

    public void getListOfDeliveryFromUrl(JSONArray jsonArray){
        deliveries = new ArrayList<Delivery>();
        for(int i=0;i<jsonArray.size();i++){
            if(!this.deliveryExist(((JSONObject)jsonArray.get(i)).get("id").toString())){
                Delivery new_delivery = new  Delivery((JSONObject)jsonArray.get(i));
                deliveries.add(new_delivery);
            }
            else{
                System.out.println("Delivery with id " +
                        ((JSONObject)jsonArray.get(i)).get("id").toString() +" already added!" );
            }
        }
        System.out.println("adding new deliveries successfully done.");
    }

    public Restaurant findRestaurant(String id){
        for(int i=0;i<restaurants.size();i++){
            if (restaurants.get(i).getId().equals(id)){
                return restaurants.get(i);
            }
        }
        return null;
    }

    public Restaurant getRestaurantWithId(String id){
        for (Restaurant restaurant:restaurants){
            if (restaurant.getId().equals(id)){
                return restaurant;
            }
        }
        return null;
    }

    public boolean restaurantAvailable(Restaurant restaurant){
        return (restaurant.distanceFromUser()<=170);
    }

    public User getUser(){
        return this.user;
    }

    public ArrayList<Restaurant> getRestaurantsAvailableForUser(){
        ArrayList<Restaurant> result = new ArrayList<Restaurant>();
        for (Restaurant restaurant:restaurants){
            if(restaurant.distanceFromUser()<=170){
                result.add(restaurant);
            }
        }
        return result;
    }

    public FoodParty findRestaurantInFoodParty(String restaurantId){
        for(int i=0;i<foodParties.size();i++){
            if(foodParties.get(i).getRestaurantId().equals(restaurantId)){
                return foodParties.get(i);
            }
        }
        return null;
    }


    public boolean isMenuFoodPartyOfRestaurant(Restaurant restaurant , String foodName){
        FoodParty foodParty = findRestaurantInFoodParty(restaurant.getId());
        if(foodParty!=null && foodParty.hasFood(foodName)){
            return true;
        }
        else{
            return false;
        }
    }

    public Delivery findDeliveryForOrder(Order order){
        HashMap<Delivery, Integer> timeToDelivery = new HashMap<Delivery,Integer>();
        for(Delivery delivery : deliveries){
            double distance_delivery_restaurant = delivery.distanceFromRestaurant(
                    getRestaurantWithId(order.getRestaurantId()));
            double distance_restaurant_user = getRestaurantWithId(order.getRestaurantId()).distanceFromUser();
            int seconds = (int)((distance_delivery_restaurant + distance_restaurant_user)/delivery.getVelocity());
            timeToDelivery.put(delivery,seconds);
        }
        for (Map.Entry<Delivery,Integer> entry : timeToDelivery.entrySet())
            System.out.println("Key = " + entry.getKey() +
                    ", Value = " + entry.getValue());
        HashMap<Delivery,Integer> sort_time_to_delivery = Utility.sortByValueDeliveryTime(timeToDelivery);
        Map.Entry<Delivery,Integer> entry = sort_time_to_delivery.entrySet().iterator().next();
        Delivery find_delivery = entry.getKey();
        Integer calc_time = entry.getValue();
        order.setTotalDeliveryTime(calc_time);
        return find_delivery;
    }


    public boolean foodPartyTimeValidationForFinalizing(User user){
        System.out.println(LocalTime.now());
        Restaurant restaurantToBuy = this.getRestaurantWithId(user.getCurrentOrder().getRestaurantId());
        FoodParty foodParty = this.findRestaurantInFoodParty(restaurantToBuy.getId());
        if(foodParty==null){
            return false;
        }
        if(!foodParty.timeAvailable()){
            return  false;
        }
        return true;
    }

    public boolean foodPartyCountValidationForFinalizing(User user){
        Restaurant restaurantToBuy = this.getRestaurantWithId(user.getCurrentOrder().getRestaurantId());
        FoodParty foodParty = this.findRestaurantInFoodParty(restaurantToBuy.getId());
        for (Map.Entry<PartyMenu,Integer> entry : user.getCurrentOrder().getPartyMenus().entrySet()){
            PartyMenu menu = foodParty.findMenuOfFood(entry.getKey().getName());
            if(menu==null){
                return false;
            }
            if(entry.getValue()>menu.getCount()){
                return false;
            }
        }
        return true;
    }


    public void changeCountOfPartyFoodUserBuy(User user){
        FoodParty foodParty = this.findRestaurantInFoodParty(user.getCurrentOrder().getRestaurantId());
        for (Map.Entry<PartyMenu,Integer> entry : user.getCurrentOrder().getPartyMenus().entrySet()){
            foodParty.decreaseCountOfPartyFood(entry.getKey().getName() , entry.getValue());
        }
    }



    private static JSONObject JSONConverter(String command) throws ParseException {
        String jsonData;
        jsonData = command.split(" ", 2)[1];
        JSONParser parser = new JSONParser();
        JSONObject jsonObject = new JSONObject();
        jsonObject = (JSONObject) parser.parse(jsonData);
        return jsonObject;
    }


    public void addRestaurantCommand(JSONObject jsonObject) throws RestaurantExist{
        String new_restaurant_name = jsonObject.get("name").toString();
        String new_restaurant_id = jsonObject.get("id").toString();
        if(isRestaurantExist(new_restaurant_id)){
            throw new RestaurantExist("You want to add new Restaurant with id " + new_restaurant_id + " which already exist!");
        }
        else{
            Restaurant new_rest = new Restaurant(jsonObject);
            restaurants.add(new_rest);
            System.out.println("adding restaurant " + new_restaurant_name +" with id " + new_restaurant_id+" successfully finished!");
        }
    }







    public String[] getTopRestaurant(HashMap<String, Double> hm) {
        HashMap<String, Double> point_sort = Utility.sortByValue(hm);
        String[] rest_names = new String[point_sort.keySet().size()];
        point_sort.keySet().toArray(rest_names);
        ArrayUtils.reverse(rest_names);
        if(rest_names.length > 2)
            return Arrays.copyOfRange(rest_names, 0, 3);
        return Arrays.copyOfRange(rest_names, 0, rest_names.length);
    }









}