package ir.ac.ut.ece.ie.servlets;


import ir.ac.ut.ece.ie.Models.Menu;
import ir.ac.ut.ece.ie.Models.Repository;
import ir.ac.ut.ece.ie.Models.Restaurant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/add_cart")
public class addToCart extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Repository repository = Repository.getInstance();
        String restaurantId = request.getParameter("restaurantId");
        String foodName = request.getParameter("foodName");
        String restaurantName = "";
        Restaurant restaurant = repository.getRestaurantWithId(restaurantId);
        if (restaurant != null) {
            restaurantName = restaurant.getName();
            Menu food = restaurant.findFoodMenu(foodName);
            if (food != null) {
                if (repository.getUser().startChoosingFood()) {
                    repository.getUser().addFoodToCart(food, restaurantName ,restaurantId);
                    System.out.println("user add food " + foodName + " with price " + food.getPrice()+
                            " from restaurant " + restaurantName +" successfully done!");
                    response.sendRedirect("show_cart.jsp");
                    return;
                }
                else if(repository.getUser().isBuyFromOtherRestaurant(restaurantName)){
                    response.sendError(404,"You already have food from other restaurant " +
                            repository.getUser().giveYourRestaurantYouBuy() + " in your food cart!");
                }
                else{
                    repository.getUser().addFoodToCart(food,restaurantName , restaurantId);
                    System.out.println("user add food " + foodName + " with price " + food.getPrice()+
                            " from restaurant " + restaurantName +" successfully done!");
                    response.sendRedirect("show_cart.jsp");
                    return;
                }
            }
        }
    }
}
