package ir.ac.ut.ece.ie.servlets;

import ir.ac.ut.ece.ie.Models.Repository;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/add_credit")
public class addCredit extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String incrementValueString = request.getParameter("credit");
        int increasement = 0;
        if(incrementValueString.equals("")){
            increasement= 0;
        }
        else{
            increasement =  Integer.parseInt(incrementValueString);
        }
        Repository.getInstance().getUser().increaseCredit((long)increasement);
        response.sendRedirect("show_user.jsp");
    }
}