package ir.ac.ut.ece.ie.servlets;

import ir.ac.ut.ece.ie.Models.Menu;
import ir.ac.ut.ece.ie.Models.Order;
import ir.ac.ut.ece.ie.Models.Repository;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/delete_food_from_order")
public class DeleteFoodFromOrder extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Repository repository = Repository.getInstance();
        int orderId = Integer.parseInt(request.getParameter("orderId"));
        String foodName = request.getParameter("foodName");
        String userId = request.getParameter("userId");
        int isFoodParty = Integer.parseInt(request.getParameter("isFoodParty"));
        Order order = repository.getUser().getOrder(orderId);
        order.deleteMenuFromOrder(isFoodParty,foodName);
        if(order.getMenus().size() + order.getPartyMenus().size() == 0){
            repository.getUser().getAllOrders().remove(order);
            repository.getUser().removingOrder();
        }
        response.sendRedirect("show_cart.jsp");
    }
}
