package ir.ac.ut.ece.ie.Models;

import java.util.ArrayList;

public class User {
    private int id;
    private String userFirstName;
    private String userLastName;
    private String phoneNumber;
    private String email;
    private long credit;
    private Order currentOrder;
    private String chosenRestaurantNameToBuy;
    private ArrayList<Order> allOrders;
    private int currentOrderId;
    private ArrayList<Order> notFoundDelivery;






    public User(int id,String name , String family , String phone , String email){
        this.id = id;
        this.userFirstName = name;
        this.userLastName = family;
        this.phoneNumber = phone;
        this.email = email;
        this.credit = 0;
        currentOrder = new Order();
        allOrders = new ArrayList<Order>();
        this.currentOrderId = 0 ;
        chosenRestaurantNameToBuy = null;
        notFoundDelivery = new ArrayList<Order>();
    }


    public boolean isChosenFoodParty(){
        return !this.currentOrder.getPartyMenus().isEmpty();
    }

    public ArrayList<Order> getNotFoundDelivery(){
        return this.notFoundDelivery;
    }


    public void addCurrentOrderToNotFoundDeliveryList(Order currentOrder){
        notFoundDelivery.add(currentOrder);
    }

    public boolean foodToBuy(){
        return (currentOrder.getMenus().size() + currentOrder.getPartyMenus().size()) != 0;
    }

    public long moneyToPayForOrder(){
        long pay=0;
        for(Menu menu: currentOrder.getMenus().keySet()){
            pay += menu.getPrice() * currentOrder.getMenus().get(menu);
        }
        for(PartyMenu menu:currentOrder.getPartyMenus().keySet()){
            pay += menu.getNewPrice() * currentOrder.getPartyMenus().get(menu);
        }
        System.out.println("total money you should pay is " + Long.toString(pay));
        return pay;
    }


    public void increaseCredit(Long increaseAmount){
        System.out.println("User add " + Long.toString(increaseAmount) + "to his credit!");
        this.credit+= increaseAmount;
    }


    public int getId(){
        return this.id;
    }

    public String getUserFirstName(){
        return this.userFirstName;
    }


    public String getUserLastName(){
        return this.userLastName;
    }


    public String getPhoneNumber(){
        return this.phoneNumber;
    }

    public String getEmail(){
        return this.email;
    }


    public long getCredit(){
        return this.credit;
    }

    public void finalizeOrder(long moneyToPay){
        this.setCurrentOrderId();
        currentOrder = new Order();
        chosenRestaurantNameToBuy = null;
        this.credit-=moneyToPay;
    }


    public void removingOrder(){
        this.chosenRestaurantNameToBuy = null;
        currentOrder = new Order();
    }

    public void addFoodToCart(Menu menu, String restaurantName , String restaurantId){
        if(this.startChoosingFood()){
            System.out.println("user start new order from " + restaurantName);
            currentOrder.setId(this.getCurrentOrderId());
            this.allOrders.add(currentOrder);
        }
        this.currentOrder.addFood(menu);
        this.currentOrder.setRestaurantName(restaurantName);
        this.currentOrder.setRestaurantId(restaurantId);
        chosenRestaurantNameToBuy = restaurantName;
    }

    public void addPartyFoodToCart(PartyMenu menu , String restaurantName , String restaurantId){
        if(this.startChoosingFood()){
            System.out.println("user start new order from " + restaurantName);
            currentOrder.setId(this.getCurrentOrderId());
            this.allOrders.add(currentOrder);
        }
        this.currentOrder.addPartyFood(menu);
        this.currentOrder.setRestaurantName(restaurantName);
        this.currentOrder.setRestaurantId(restaurantId);
        chosenRestaurantNameToBuy = restaurantName;
    }

    public boolean startChoosingFood(){
        return chosenRestaurantNameToBuy==null;

    }

    public String giveYourRestaurantYouBuy(){
        return chosenRestaurantNameToBuy;
    }

    public boolean isBuyFromOtherRestaurant(String name){
        return !chosenRestaurantNameToBuy.equals(name);
    }

    public void setRestaurantToBuyFrom(String name){
        this.chosenRestaurantNameToBuy= name;
    }

    public Order getCurrentOrder(){
        return currentOrder;
    }

    public ArrayList<Order> getAllOrders() { return allOrders; }


    public String getFullName() {
        return this.getUserFirstName() + " " + this.getUserLastName();
    }

    public int getCurrentOrderId() { return currentOrderId; }

    public void setCurrentOrderId() { currentOrderId += 1; }

    public Order getOrder(int id){
        for(int i=0;i<allOrders.size();i++){
            if(allOrders.get(i).getId()==id){
                return allOrders.get(i);
            }
        }
        return null;
    }

}
