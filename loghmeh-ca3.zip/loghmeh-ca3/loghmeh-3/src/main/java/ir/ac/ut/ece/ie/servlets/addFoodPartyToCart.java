package ir.ac.ut.ece.ie.servlets;

import ir.ac.ut.ece.ie.Models.FoodParty;
import ir.ac.ut.ece.ie.Models.PartyMenu;
import ir.ac.ut.ece.ie.Models.Repository;
import ir.ac.ut.ece.ie.Models.Restaurant;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/add_to_cart_food_party")
public class addFoodPartyToCart extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Repository repository = Repository.getInstance();
        String userId = request.getParameter("userId");
        String restaurantId = request.getParameter("restaurantId");
        String foodName = request.getParameter("foodName");
        Restaurant restaurant = repository.getRestaurantWithId(restaurantId);
        FoodParty foodParty = repository.findRestaurantInFoodParty(restaurantId);
        if (foodParty == null) {
            response.sendError(404, "restaurant " + restaurant.getName() + " with id " +
                    restaurantId + " not providing food party!(not exist in food party)");
            return;
        }
        PartyMenu menu = foodParty.findMenuOfFood(foodName);
        if (menu == null) {
            response.sendError(404, foodName + " not exist in restaurant " + restaurant.getName() +
                    "with id " + restaurantId + " as a food party!");
            return;
        }
        if (!foodParty.timeAvailable()) {
            response.sendError(404, "too late to add this food to cart.");
            return;
        }
        if (!menu.canChooseThisMenu()) {
            response.sendError(404, "Limited number of this food was available.It is finished!");
            return;
        }

        if (repository.getUser().startChoosingFood()) {
            repository.getUser().addPartyFoodToCart(menu, restaurant.getName(), restaurantId);
            System.out.println("user add food " + foodName + " with new price " + menu.getNewPrice() +
                    " from restaurant " + restaurant.getName() + " successfully done!");
            response.sendRedirect("show_cart.jsp");
            return;
        } else if (repository.getUser().isBuyFromOtherRestaurant(restaurant.getName())) {
            response.sendError(404, "You already have food from other restaurant " +
                    repository.getUser().giveYourRestaurantYouBuy() + " in your food cart!");
        } else {
            repository.getUser().addPartyFoodToCart(menu, restaurant.getName(), restaurantId);
            System.out.println("user add food " + foodName + " with new price " + menu.getNewPrice() +
                    " from restaurant " + restaurant.getName() + " successfully done!");
            response.sendRedirect("show_cart.jsp");
            return;
        }
    }
}

