package ir.ac.ut.ece.ie.Models;

import org.json.simple.JSONObject;



public class PartyMenu {
    private String name;
    private String description;
    private double popularity;
    private long oldPrice;
    private String urlImage;
    private long newPrice;
    private int count;




    public PartyMenu(JSONObject menuInfo){
        this.name = menuInfo.get("name").toString();
        this.description = menuInfo.get("description").toString();
        this.popularity = (double) menuInfo.get("popularity");
        this.oldPrice = (long) menuInfo.get("oldPrice");
        this.urlImage = menuInfo.get("image").toString();
        this.newPrice = (long) menuInfo.get("price");
        this.count = Integer.parseInt(menuInfo.get("count").toString());
    }


    public String getName(){
        return name;
    }

    public double getPopularity(){
        return popularity;
    }

    public String getDescription() { return this.description; }

    public long getOldPrice() { return this.oldPrice; }

    public long getNewPrice(){
        return this.newPrice;
    }

    public String getUrlImage(){
        return this.urlImage;
    }

    public int getCount(){
        return this.count;
    }

    public void decreaseCount(int num){
        this.count-=num;
    }

    public boolean canChooseThisMenu(){
        return count>=1;
    }

}
