package ir.ac.ut.ece.ie.servlets;

import ir.ac.ut.ece.ie.Models.*;
import ir.ac.ut.ece.ie.utilities.Utility;
import org.json.simple.JSONArray;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalTime;

@WebServlet("/finalize_order")
public class finalizeOrder extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Repository repository = Repository.getInstance();
        long userCredit = repository.getUser().getCredit();
        boolean foodToBuy = repository.getUser().foodToBuy();
        long moneyToPay = repository.getUser().moneyToPayForOrder();
        if (repository.isUserSelectFoodParty(repository.getUser()) && !repository.foodPartyTimeValidationForFinalizing(repository.getUser())) {
            response.sendError(404, "Time validation error for food in your list!");
            return;
        }
        if (!repository.foodPartyCountValidationForFinalizing(repository.getUser())) {
            response.sendError(404, "Count validation error for food in your list!");
            return;
        }
        if (!foodToBuy) {
            response.sendError(404, "You may not choose any food to buy!");
            return;
        }
        if (userCredit < moneyToPay) {
            response.sendError(404, "Not enough money to buy!");
            return;
        }
        System.out.println("User finalize order!");
        repository.getUser().getCurrentOrder().setStatus(DeliveryStatus.FINDING_DELIVERY);
        JSONArray jsonArray = Utility.requestDeliveryApiGetList();
        repository.getListOfDeliveryFromUrl(jsonArray);
        if (repository.getDeliveries().size() == 0) {
            System.out.println("No delivery available now.Handle later.put this order in notfound array list!");
            repository.getUser().addCurrentOrderToNotFoundDeliveryList(
                    repository.getUser().getCurrentOrder());
            repository.changeCountOfPartyFoodUserBuy(repository.getUser());
        } else {
            System.out.println("try to find delivery with min time!");
            Delivery findDelivery = repository.findDeliveryForOrder(
                    repository.getUser().getCurrentOrder());
            System.out.println("delivery find is:==> " + findDelivery);
            repository.getUser().getCurrentOrder().orderGiveToDeliverySetTime(LocalTime.now(),
                    findDelivery.getId());
            repository.getUser().getCurrentOrder().setStatus(DeliveryStatus.DELIVERING);
        }
        repository.getUser().finalizeOrder(moneyToPay);
        repository.changeCountOfPartyFoodUserBuy(repository.getUser());
        response.sendRedirect("index.jsp");
    }


}
